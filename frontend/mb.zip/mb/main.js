const dateElem = document.querySelector(".date");
const receiptElem = document.querySelector(".receipt");
const secretButton = document.querySelector(".secret");
const nameElems = document.querySelectorAll(".name");
const summElems = document.querySelectorAll(".summ");
const phoneElem = document.querySelector(".phone");

const formatNumber = (number) => (number < 10 ? "0" + number : number);

const randomInteger = (min, max) => {
  let rand = min + Math.random() * (max + 1 - min);
  return Math.floor(rand);
};

const date = new Date();
const currentDate = `${formatNumber(date.getDate())}.${formatNumber(
  date.getMonth()
)}.${date.getFullYear()}, ${formatNumber(date.getHours())}:${formatNumber(
  date.getMinutes()
)}`;

const getRandomRecipt = () => {
  let result = "";

  for (let i = 0; i < 9; i++) {
    result += randomInteger(0, 9);
  }

  return result;
};

dateElem.innerHTML = currentDate;
receiptElem.innerHTML = `P0815${getRandomRecipt()}`;

let secretButtonTapsCount = 0;

secretButton.addEventListener("click", () => {
  ++secretButtonTapsCount;
  if (secretButtonTapsCount > 3) {
    secretButtonTapsCount = 0;

    let summ = 0;
    while (!summ) {
      summ = prompt("Введите сумму");
    }

    let name = "";
    while (!name) {
      name = prompt("Введите имя получателя");
    }

    let phone = 0;
    while (!phone) {
      phone = prompt("Введите номер телефона");
    }

    summElems.forEach((elem) => (elem.innerHTML = summ));
    nameElems.forEach((elem) => (elem.innerHTML = name));
    phoneElem.innerHTML = phone;
  }
});
