// import { Tour } from "../@types";
// import tour1_1 from "../assets/term/tour1_1.png";
import tour1_2 from "../assets/term/tour1_2.png";
import tour1_3 from "../assets/term/tour1_3.png";
import tour1_4 from "../assets/term/tour1_4.png";
import tour1_5 from "../assets/term/tour1_5.png";
import tour1_6 from "../assets/term/tour1_6.png";
import tour1_7 from "../assets/term/tour1_7.png";
import tour1_8 from "../assets/term/tour1_8.png";
import tour1_9 from "../assets/term/tour1_9.png";
import tour1_10 from "../assets/term/tour1_10.png";
import tour1_11 from "../assets/term/tour1_11.png";
import tour1 from "../assets/term/tour1_1.jpg";
import tour2 from "../assets/term/tour2.jpg";

export const tours = [
  {
    id: 1,
    name: "3 day winter horse trek to Song-Kol",
    images: [tour1],
    tour_time: "3 days",
    number_of_people: 3,
    when_is_tour: "November-May",
    program: [
      {
        id: 1,
        name: `Kyzart - "Kilemche" Shepherd's House`,
        day: 1,
        locations: [
          {
            name_location: "Kyzart",
            type: "Питание",
            description_location:
              "Travel to Kyzart village by public transport or taxi, where our team will meet you. Enjoy lunch at a local house before embarking on a 3-4 hour horse ride to Kilemche pasture. Along the way, marvel at picturesque landscapes, small rivers, and winter shepherd houses. Reach a local family house on the mountains for the night, meeting the shepherd and enjoying hot tea or kymyz.",
            nextTransport: { time: "3-4h", type: "horse" },
          },
          {
            name_location: "Kilemche",
            type: "Ночлег",
          },
        ],
      },
      {
        id: 2,
        name: `"Kilemche" Shepherd's House - Son-Kul Lake`,
        day: 2,
        locations: [
          {
            name_location: "Kilemche",
            type: "Место",
            description_location:
              "After breakfast, ride to Son-Kul Lake through Tuz-Ashuu pass (3400 m). Admire a stunning lake view at the top, followed by a walk to the yurt camp for the night. Have lunch in a yurt, explore the lakeside, and engage with locals. Optional activities include winter games, riding sleigh with horses. Enjoy dinner and gaze at the starry sky. Spend the night in a warm yurt.",
            nextTransport: { time: "3 h", type: "horse" },
          },
          {
            name_location: "Son-Kul Lake",
            type: "Ночлег",
          },
        ],
      },
      {
        id: 3,
        name: `Son-Kul Lake - Kyzart`,
        day: 3,
        locations: [
          {
            name_location: "Son-Kul lake",
            type: "Питание",
            description_location:
              "Return to Kyzart village after breakfast, passing through Uzbek Pass (3,200 m). Have lunch in Kyzart before continuing your winter journey.",
            nextTransport: { time: "4 - 4.5 h", type: "horse" },
          },
          {
            name_location: "Kyzart",
            type: "Питание",
          },
        ],
      },
    ],
    prices: {
      price_includes: [
        "Accommodation and meals",
        "Cook with horse (cook will go the day before and prepare the yurt for your arrival, cooking and heating)",
        "Professional horsemen-guides",
        "Specialized horse equipments",
        "One horsemen per 3 persons",
        "Special horse equipments",
        "Helmets",
        "Horses",
      ],
      price_not_includes: [
        "Air travel and taxes",
        "Alcoholic beverages",
        "Transportation expenses",
      ],
    },
    price_details: [
      { id: 1, person: 1, in_com: 25300, per_person: 25300 },
      { id: 2, person: 2, in_com: 33800, per_person: 16900 },
      { id: 3, person: 3, in_com: 42300, per_person: 14100 },
      { id: 4, person: 4, in_com: 59200, per_person: 14800 },
      { id: 5, person: 5, in_com: 67700, per_person: 13540 },
      { id: 6, person: 6 },
      { id: 7, person: 7 },
      { id: 8, person: 8 },
      { id: 9, person: 9 },
      { id: 10, person: 10 },
    ],
    tips: {
      tittle: "What to bring?",
      what_to_bring: [
        "Waterproof Backpack",
        "Wear comfortable long Warm Clothes: (Waterproof jacket, temp clothing, long pants) ",
        "Comfortable Boots with a Heel",
        "Gloves and a Hat",
        "Sunglasses",
        "Compact Sleeping Bag (if you have)",
        "Water Bottle",
        "Sun Protection Cream",
        "First Aid Kit",
        "Personal Hygiene Items",
      ],
      tittle_2: "About the weather",
      description:
        "In winter, temperatures at Son-Kol can range from -10 to -30 degrees Celsius (-14 to -22 degrees Fahrenheit), with the possibility of even lower temperatures during particularly cold spells.",
    },
    photos: {
      images: [
        tour1_2,
        tour1_3,
        tour1_4,
        tour1_5,
        tour1_6,
        tour1_7,
        tour1_8,
        tour1_9,
        tour1_10,
        tour1_11,
      ],
    },
    similarTours: [
      {
        id: 2,
        name: "2 day winter horse trek to Song-Kol",
        tour_time: "2 days",
        number_of_people: 8,
        when_is_tour: "November-May",
        images: [tour2],
      },
    ],
  },
  {
    id: 2,
    name: "2 day winter horse trek to Song-Kol",
    tour_time: "2 days",
    number_of_people: 8,
    when_is_tour: "November-May",
    images: [tour2],
    program: [
      {
        id: 1,
        name: `Kyzart - Song-Kul`,
        day: 1,
        locations: [
          {
            name_location: "Kyzart",
            type: "Питание",
            description_location:
              "The tour will start at the village of Kyzart. You will have lunch in a small local house (it is possible to start the tour before lunch if you spend the night before in Kyzart). After lunch, the horseback ride to the lake will start through the pass Kara-kyia (3,300m). The ride will last up to 4.5 hours. The pass offers a magnificent panoramic view of the Son Kul mountains. Experience the evening activities of releasing herds and preparing dinner in the yurt. Dinner and overnight stay in the yurt.",
            nextTransport: { time: "4-5 h", type: "horse" },
          },
          {
            name_location: "Song-Kol lake",
            type: "Ночлег",
          },
        ],
      },
      {
        id: 2,
        name: `Song-Kul - Kyzart`,
        day: 2,
        locations: [
          {
            name_location: "Song-Kol lake",
            type: "Питание",
            description_location:
              "After breakfast, return to Kyzart village via Uzbek pass. If you desire more time at Son-Kul Lake, we can extend the visit until after lunch. Enjoy lunch in the village of Kyzart, marking the end of the tour.",
            nextTransport: { time: "4-5 h", type: "horse" },
          },
          {
            name_location: "Kyzart",
            type: "Питание",
          },
        ],
      },
    ],
    prices: {
      price_includes: [
        "Accommodation and meals",
        "Cook with horse (cook will go the day before and prepare the yurt for your arrival, cooking and heating)",
        "Professional horsemen-guides",
        "Specialized horse equipments",
        "One horsemen per 3 persons",
        "Special horse equipments",
        "Helmets",
        "Horses",
      ],
      price_not_includes: [
        "Air travel and taxes",
        "Alcoholic beverages",
        "Transportation expenses",
      ],
    },
    price_details: [
      { id: 1, person: 1, in_com: 16600, per_person: 16600 },
      { id: 2, person: 2, in_com: 22200, per_person: 11100 },
      { id: 3, person: 3, in_com: 27400, per_person: 9150 },
      { id: 4, person: 4, in_com: 39400, per_person: 9850 },
      { id: 5, person: 5, in_com: 43800, per_person: 8760 },
      { id: 6, person: 6, in_com: 49200, per_person: 8200 },
      { id: 7, person: 7 },
      { id: 8, person: 8 },
      { id: 9, person: 9 },
      { id: 10, person: 10 },
    ],
    tips: {
      tittle: "What to bring?",
      what_to_bring: [
        "Waterproof Backpack",
        "Wear comfortable long Warm Clothes: (Waterproof jacket, temp clothing, long pants) ",
        "Comfortable Boots with a Heel",
        "Gloves and a Hat",
        "Sunglasses",
        "Compact Sleeping Bag (if you have)",
        "Water Bottle",
        "Sun Protection Cream",
        "First Aid Kit",
        "Personal Hygiene Items",
      ],
      tittle_2: "About the weather",
      description:
        "In winter, temperatures at Son-Kol can range from -10 to -30 degrees Celsius (-14 to -22 degrees Fahrenheit), with the possibility of even lower temperatures during particularly cold spells.",
    },
    photos: {
      images: [
        tour1_2,
        tour1_3,
        tour1_4,
        tour1_5,
        tour1_6,
        tour1_7,
        tour1_8,
        tour1_9,
        tour1_10,
        tour1_11,
      ],
    },
    similarTours: [
      {
        id: 1,
        name: "3 day winter horse trek to Song-Kol",
        images: [tour1],
        tour_time: "3 days",
        number_of_people: 3,
        when_is_tour: "November-May",
      },
    ],
  },
];
