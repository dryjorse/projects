declare module "react-transition-group" {
  const content: any;
  export default content;
}
declare module "swiper" {
  const content: any;
  export default content;
}
declare module "use-match-media" {
  const content: any;
  export default content;
}
declare module "lodash.debounce" {
  const content: any;
  export default content;
}