export default function FAQ() {
  return (
    <div>
      <h2>FAQ</h2>
    </div>
  );
}
